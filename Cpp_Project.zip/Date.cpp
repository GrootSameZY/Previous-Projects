#include <iomanip>

#include "Date.h"

namespace minirisk {

	struct DateInitializer : std::array<unsigned, Date::n_years>
	{
		DateInitializer()
		{
			for (unsigned i = 0, s = 0, y = Date::first_year; i < size(); ++i, ++y) {
				(*this)[i] = s;
				s += 365 + (Date::is_leap_year(y) ? 1 : 0);
			}
		}
	};

	const std::array<unsigned, 12> Date::days_in_month = { {31,28,31,30,31,30,31,31,30,31,30,31} };
	const std::array<unsigned, 12> Date::days_ytd{ {0,31,59,90,120,151,181,212,243,273,304,334} };
	const std::array<unsigned, Date::n_years> Date::days_epoch(static_cast<const std::array<unsigned, Date::n_years>&>(DateInitializer()));

	/* The function checks if a given year is a leap year.
		Leap year must be a multiple of 4, but it cannot be a multiple of 100 without also being a multiple of 400.
	*/
	bool Date::is_leap_year(unsigned year)
	{
		return ((year % 4 != 0) ? false : (year % 100 != 0) ? true : (year % 400 != 0) ? false : true);
	}

	// The function pads a zero before the month or day if it has only one digit.
	std::string Date::padding_dates(unsigned month_or_day)
	{
		std::ostringstream os;
		os << std::setw(2) << std::setfill('0') << month_or_day;
		return os.str();
	}

	void Date::check_valid(unsigned y, unsigned m, unsigned d)
	{
		MYASSERT(y >= first_year, "The year must be no earlier than year " << first_year << ", got " << y);
		MYASSERT(y < last_year, "The year must be smaller than year " << last_year << ", got " << y);
		MYASSERT(m >= 1 && m <= 12, "The month must be a integer between 1 and 12, got " << m);
		unsigned dmax = days_in_month[m - 1] + ((m == 2 && is_leap_year(y)) ? 1 : 0);
		MYASSERT(d >= 1 && d <= dmax, "The day must be a integer between 1 and " << dmax << ", got " << d);
	}

	unsigned Date::day_of_year(unsigned y, unsigned m, unsigned d, bool leap) const
	{
		return days_ytd[m - 1] + ((m > 2 && leap) ? 1 : 0) + (d - 1);
	}

	int* Date::to_number(unsigned m_s)
	{
		unsigned a = 73048;
		unsigned year;
		unsigned month;
		unsigned day;
		unsigned y_4;
		unsigned y_now;
		unsigned m_s_now;
		bool leap;
		if (m_s <= a)
		{
			if (m_s <= 364)
			{
				year = 1900;
				m_s_now = m_s + 1;
				leap = false;
			}
			else
			{
				y_4 = (m_s - 364) / (365 * 3 + 366);
				y_now = (m_s - 364) % (365 * 3 + 366);
				year = y_4 * 4 + 1901;
				if (y_now <= 365 * 3)
				{
					year = year + (y_now / 365);
					m_s_now = (y_now % 365);
					if (m_s_now == 0) {
						year = year - 1;
						m_s_now = m_s_now + 365;
					}
					leap = false;
				}
				else
				{
					year = year + 3;
					m_s_now = y_now - 365 * 3;
					leap = true;
				}
			}
		}
		else
		{
			m_s = m_s - a - 1;
			if (m_s <= 364)
			{
				year = 2100;
				m_s_now = m_s + 1;
				leap = false;
			}
			else
			{
				y_4 = (m_s - 364) / (365 * 3 + 366);
				y_now = (m_s - 364) % (365 * 3 + 366);
				year = y_4 * 4 + 2101;
				if (y_now <= 365 * 3)
				{
					year = year + (y_now / 365);
					m_s_now = (y_now % 365);
					if (m_s_now == 0) {
						year = year - 1;
						m_s_now = m_s_now + 365;
					}
					leap = false;
				}
				else
				{
					year = year + 3;
					m_s_now = y_now - 365 * 3;
					leap = true;
				}
			}
		}
		if (leap == false)
		{
			for (month = 1; month <= 11; ++month)
			{
				if (m_s_now <= days_ytd[month])
					break;
			}
			day = m_s_now - days_ytd[month - 1];
		}
		else
		{
			if (m_s_now <= 31)
			{
				month = 1;
				day = m_s_now;
			}
			else if (m_s_now <= 60)
			{
				month = 2;
				day = m_s_now - 31;
			}
			else
			{
				for (month = 3; month <= 11; ++month)
				{
					if (m_s_now <= days_ytd[month] + 1)
					{
						break;
					}
				}
				day = m_s_now  - 1 - days_ytd[month - 1];
			}
		}
		static int d[3];
		d[0] = day;
		d[1] = month;
		d[2] = year;
		return d;
	}


	/*  The function calculates the distance between two Dates.
		d1 > d2 is allowed, which returns the negative of d2-d1.
	*/
	long operator-(const Date& d1, const Date& d2)
	{
		unsigned s1 = d1.m_s;
		unsigned s2 = d2.m_s;
		return static_cast<long>(s1) - static_cast<long>(s2);
	}

} // namespace minirisk




