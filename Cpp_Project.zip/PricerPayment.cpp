#include "PricerPayment.h"
#include "TradePayment.h"
#include "CurveDiscount.h"

namespace minirisk {

PricerPayment::PricerPayment(const TradePayment& trd, std::string& configuration, std::shared_ptr<const FixingDataServer>& fds)
    : m_amt(trd.quantity())
    , m_dt(trd.delivery_date())
    , m_ir_curve(ir_curve_discount_name(trd.ccy()))
    , m_fxspot_curve(fx_spot_name(trd.ccy(), configuration))
    , m_fx_ccy(trd.ccy() == "USD" ? "" : configuration)
    , m_fds(fds)
{
}

double PricerPayment::price(Market& mkt) const
{
    ptr_disc_curve_t disc = mkt.get_discount_curve(m_ir_curve);
    ptr_fxspot_curve_t fxspot_curve = mkt.get_fxspot_curve(m_fxspot_curve);
    double df = disc->df(m_dt); // this throws an exception if m_dt<today
    double spot = fxspot_curve->spot();
    // m_fx_ccy check not required any more since if the trade currency is USD and config is USD spot =1.
    df *= spot;
    

    return m_amt * df;
}

} // namespace minirisk