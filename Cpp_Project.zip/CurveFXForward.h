#pragma once
#include "ICurve.h"

namespace minirisk {

    struct Market;

    struct CurveFXForward : ICurveFXForward
    {
        virtual string name() const { return m_name; }

        CurveFXForward(Market* mkt, const Date& today, const string& curve_name);

        // compute the fx forward rate
        double fwd(const Date& t) const;

        virtual Date today() const { return m_today; }

    private:
        Date   m_today;
        string m_name;
        string m_ccy1;
        string m_ccy2;
        ptr_disc_curve_t m_ratecurve_ccy1;
        ptr_disc_curve_t m_ratecurve_ccy2;
        ptr_fxspot_curve_t m_fxspot_curve;

    };

} // namespace minirisk

#pragma once

