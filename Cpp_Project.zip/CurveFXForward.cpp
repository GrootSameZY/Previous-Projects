#include "CurveDiscount.h"
#include "CurveFXForward.h"
#include "CurveFXSpot.h"
#include "Market.h"
#include "Streamer.h"

#include <cmath>


namespace minirisk {

CurveFXForward::CurveFXForward(Market* mkt, const Date& today, const string& curve_name)
    : m_today(today)
    , m_name(curve_name)
    , m_ccy1(curve_name.substr(fx_forward_prefix.length(), 3))//get the first currrency name. FX.SPOT.XXX.YYY -> XXX
    , m_ccy2(curve_name.substr(fx_forward_prefix.length() + 4, 3))//get the second currrency name. FX.SPOT.XXX.YYY -> YYY
    , m_ratecurve_ccy1(mkt->get_discount_curve(ir_curve_discount_name(m_ccy1)))
    , m_ratecurve_ccy2(mkt->get_discount_curve(ir_curve_discount_name(m_ccy2)))
    , m_fxspot_curve (mkt->get_fxspot_curve(fx_spot_name(m_ccy1, m_ccy2)))
{
}

double  CurveFXForward::fwd(const Date& t) const
{
    return m_fxspot_curve->spot()* m_ratecurve_ccy1->df(t)/ m_ratecurve_ccy2->df(t);
}

} // namespace minirisk
