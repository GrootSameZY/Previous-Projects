#include "TradeFXForward.h"
#include "PricerFXForward.h"

namespace minirisk {

ppricer_t TradeFXForward::pricer(string& configuration, std::shared_ptr<const FixingDataServer>& fds) const 
{
    return ppricer_t(new PricerFXForward(*this, configuration, fds));
}

} // namespace minirisk