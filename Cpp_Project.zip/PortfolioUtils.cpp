#include "Global.h"
#include "PortfolioUtils.h"
#include "TradePayment.h"
#include "TradeFXForward.h"

#include <numeric>
#include <exception>
#include <cmath>

namespace minirisk {

void print_portfolio(const portfolio_t& portfolio)
{
	std::for_each(portfolio.begin(), portfolio.end(), [](auto& pt) { pt->print(std::cout); });
}

std::vector<ppricer_t> get_pricers(const portfolio_t& portfolio, string& configuration, std::shared_ptr<const FixingDataServer>& fds)
{
	std::vector<ppricer_t> pricers(portfolio.size());
	std::transform(portfolio.begin(), portfolio.end(), pricers.begin()
		, [&configuration, &fds](auto& pt) -> ppricer_t { return pt->pricer(configuration, fds); });
	return pricers;
}

portfolio_values_t compute_prices(const std::vector<ppricer_t>& pricers, Market& mkt)
{
	portfolio_values_t prices(pricers.size());
	std::transform(pricers.begin(), pricers.end(), prices.begin()
		, [&mkt](auto& pp) -> std::pair<double, string> {
			std::pair<double, string> pr;
			try {
				pr.first = pp->price(mkt);
				pr.second = "";
			}
			catch (std::exception& e) {
				pr.first = std::numeric_limits<double>::quiet_NaN();
				pr.second = e.what();
			}
			return pr;
		});
	return prices;
}

std::pair<double, std::vector<std::pair<size_t, string>>> portfolio_total(const portfolio_values_t& values)
{
	std::pair<double, std::vector<std::pair<size_t, string>>> result;
	double total = 0.0;
	size_t i = 0;
	std::vector<std::pair<size_t, string>> f;
	for (const auto& d : values) {
		if (std::isnan(d.first)) {
			f.push_back(std::pair<size_t, string>(i, d.second));
		}
		else {
			total = total + d.first;
		}
		i++;
	}
	result.first = total;
	result.second = f;
	return result;
}

std::vector<std::pair<string, portfolio_values_t>> compute_pv01Bucketed(const std::vector<ppricer_t>& pricers, const Market& mkt)
{
	std::vector<std::pair<string, portfolio_values_t>> pv01;  // PV01 per trade

	const double bump_size = 0.01 / 100;
	// filter risk factors related to IR
	auto base = mkt.get_risk_factors(ir_rate_prefix + "*.[A-Z]{3}");
	//auto base = mkt.get_risk_factors(ir_rate_prefix + "*");

	// Make a local copy of the Market object, because we will modify it applying bumps
	// Note that the actual market objects are shared, as they are referred to via pointers
	Market tmpmkt(mkt);

	// compute prices for perturbated markets and aggregate results
	pv01.reserve(base.size());
	for (const auto& d : base) {
		std::vector<std::pair<double, string>> pv_up, pv_dn;
		std::vector<std::pair<string, double>> bumped(1, d);
		pv01.push_back(std::make_pair(d.first, portfolio_values_t(pricers.size())));

		// bump down and price
		bumped[0].second = d.second - bump_size;
		tmpmkt.set_risk_factors(bumped);
		pv_dn = compute_prices(pricers, tmpmkt);

		// bump up and price
		bumped[0].second = d.second + bump_size; // bump up
		tmpmkt.set_risk_factors(bumped);
		pv_up = compute_prices(pricers, tmpmkt);
		
		// restore original market state for next iteration
		// (more efficient than creating a new copy of the market at every iteration)
		bumped[0].second = d.second;
		tmpmkt.set_risk_factors(bumped);

		// compute estimator of the derivative via central finite differences
		double dr = 2.0 * bump_size;
		std::transform(pv_up.begin(), pv_up.end(), pv_dn.begin(), pv01.back().second.begin()
			, [dr](std::pair<double, string> hi, std::pair<double, string> lo) -> std::pair<double, string> {
				
				std::pair<double, string> result;
				if (std::isnan(hi.first)) {
					result.first = hi.first;
					result.second = hi.second;
				}
				else if (std::isnan(lo.first)) {
					result.first = lo.first;
					result.second = lo.second;
				}
				else {
					result.first = (hi.first - lo.first) / dr;
					result.second = "";
				}
				return result;
			});
	}
	
	return pv01;
}

std::vector<std::pair<string, portfolio_values_t>> compute_pv01Parallel(const std::vector<ppricer_t>& pricers, const Market& mkt)
{
	std::vector<std::pair<string, portfolio_values_t>> pv01;  // PV01 per trade

	const double bump_size = 0.01 / 100;
	
	// filter risk factors related to IR
	auto base = mkt.get_risk_factors(ir_rate_prefix + "*.[A-Z]{3}");
	//auto base = mkt.get_risk_factors(ir_rate_prefix + "*");

	// Make a local copy of the Market object, because we will modify it applying bumps
	// Note that the actual market objects are shared, as they are referred to via pointers
	Market tmpmkt(mkt);
	
	string ccy = "";
	std::map<string, double> ccynames;
	for (const auto& d : base) {
		ccy = d.first;
		ccy = ccy.substr(ccy.length() - 3, 3);
		ccynames.emplace(ccy, 0.0);
	}

	// compute prices for perturbated markets and aggregate results
	pv01.reserve(ccynames.size());
	for (const auto& ccy : ccynames) {
		std::vector<std::pair<double, string>> pv_up, pv_dn;
		base = mkt.get_risk_factors(ir_rate_prefix + "*." + ccy.first);
		pv01.push_back(std::make_pair(ir_rate_prefix + ccy.first, portfolio_values_t(pricers.size())));
		
		std::vector<std::pair<string, double>> bumped(base.begin(), base.end());

		unsigned int i = 0;
		// bump down and price
		for (i = 0; i < base.size(); i++) {
			bumped[i].second = base[i].second - bump_size;
		}

		tmpmkt.set_risk_factors(bumped);
		pv_dn = compute_prices(pricers, tmpmkt);
		
		// bump up and price
		for (i = 0; i < base.size(); i++) {
			bumped[i].second = base[i].second + bump_size;
		}
		tmpmkt.set_risk_factors(bumped);
		pv_up = compute_prices(pricers, tmpmkt);
		
		// restore original market state for next iteration
		tmpmkt.set_risk_factors(base); //reset the temporary market

		// compute estimator of the derivative via central finite differences
		double dr = 2.0 * bump_size;
		std::transform(pv_up.begin(), pv_up.end(), pv_dn.begin(), pv01.back().second.begin()
			, [dr](std::pair<double, string> hi, std::pair<double, string> lo) -> std::pair<double, string> {
				
				std::pair<double, string> result;
				if (std::isnan(hi.first)) {
					result.first = hi.first;
					result.second = hi.second;
				}
				else if (std::isnan(lo.first)) {
					result.first = lo.first;
					result.second = lo.second;
				}
				else {
					result.first = (hi.first - lo.first) / dr;
					result.second = "";
				}
				return result;
			});
	}
	return pv01;
}

std::vector<std::pair<string, portfolio_values_t>> fx_delta(const std::vector<ppricer_t>& pricers, const Market& mkt)
{
	std::vector<std::pair<string, portfolio_values_t>> fxdelta;  // FX Delta

	const double bump_size = 0.1 / 100;
	
	// filter risk factors related to FX
	auto base = mkt.get_risk_factors(fx_spot_prefix + "*.[A-Z]{3}");
	//auto base = mkt.get_risk_factors(ir_rate_prefix + "*");

	Market tmpmkt(mkt);
	string ccy = "";
	std::map<string, double> ccynames;
	for (const auto& d : base) {
		ccy = d.first;
		ccy = ccy.substr(ccy.length() - 3, 3);
		ccynames.emplace(ccy, 0.0);
	}
	
	// compute prices for perturbated markets and aggregate results
	fxdelta.reserve(ccynames.size());
	for (const auto& ccy : ccynames) {
		std::vector<std::pair<double, string>> pv_up, pv_dn;
		base = mkt.get_risk_factors(fx_spot_prefix + "*." + ccy.first);
		fxdelta.push_back(std::make_pair(fx_spot_prefix + ccy.first, portfolio_values_t(pricers.size())));

		std::vector<std::pair<string, double>> bumped(base.begin(), base.end());
		
		unsigned int i = 0;
		// bump down and price
		for (i = 0; i < base.size(); i++) {
			bumped[i].second = base[i].second * (1 - bump_size);
		}
		
		tmpmkt.set_risk_factors(bumped);
		pv_dn = compute_prices(pricers, tmpmkt);

		// bump up and price
		for (i = 0; i < base.size(); i++) {
			bumped[i].second = base[i].second * (1 + bump_size); 
		}
		tmpmkt.set_risk_factors(bumped);
		pv_up = compute_prices(pricers, tmpmkt);

		// restore original market state for next iteration
		tmpmkt.set_risk_factors(base); //reset the temporary market

		// compute estimator of the derivative via central finite differences
		double dr = 2.0 * bump_size * base[0].second;
		std::transform(pv_up.begin(), pv_up.end(), pv_dn.begin(), fxdelta.back().second.begin()
			, [dr](std::pair<double, string> hi, std::pair<double, string> lo) -> std::pair<double, string> {
				
				std::pair<double, string> result;
				if (std::isnan(hi.first)) {
					result.first = hi.first;
					result.second = hi.second;
				}
				else if (std::isnan(lo.first)) {
					result.first = lo.first;
					result.second = lo.second;
				}
				else {
					result.first = (hi.first - lo.first) / dr;
					result.second = "";
				}
				return result;
			});
	}
	return fxdelta;
}


ptrade_t load_trade(my_ifstream& is)
{
	string name;
	ptrade_t p;

	// read trade identifier
	guid_t id;
	is >> id;
	
	if (id == TradePayment::m_id)
		p.reset(new TradePayment);
	else if (id == TradeFXForward::m_id)
		p.reset(new TradeFXForward);
	else
		THROW("Unknown trade type:" << id);
	
	p->load(is);

	return p;
}

void save_portfolio(const string& filename, const std::vector<ptrade_t>& portfolio)
{
	// test saving to file
	my_ofstream of(filename);
	for (const auto& pt : portfolio) {
		pt->save(of);
		of.endl();
	}
	of.close();
}

std::vector<ptrade_t> load_portfolio(const string& filename)
{
	std::vector<ptrade_t> portfolio;

	// test reloading the portfolio
	my_ifstream is(filename);
	while (is.read_line())
		portfolio.push_back(load_trade(is));

	return portfolio;
}

void print_price_vector(const string& name, const portfolio_values_t& values)
{
	std::pair<double, std::vector<std::pair<size_t, string>>> t = portfolio_total(values);
	std::cout
		<< "========================\n"
		<< name << ":\n"
		<< "========================\n"
		<< "Total:  " << t.first << "\n"
		<< "Errors: " << t.second.size() << "\n"
		<< "\n========================\n";
	
	for (size_t i = 0, n = values.size(); i < n; ++i) {
		if (std::isnan(values[i].first)) {
			std::cout << std::setw(5) << i << ": " << values[i].second << "\n";
		}
		else {
			std::cout << std::setw(5) << i << ": " << values[i].first << "\n";
		}
	}
	
	std::cout << "========================\n\n";
}

} // namespace minirisk
