#include "PricerFXForward.h"
#include "TradeFXForward.h"
#include "CurveDiscount.h"

namespace minirisk {
    PricerFXForward::PricerFXForward(const TradeFXForward& trd, std::string& configuration, std::shared_ptr<const FixingDataServer>& fds)
        : m_amt(trd.quantity())
        , m_strike(trd.strike())
        , m_settle_dt(trd.settle_date())
        , m_fixing_dt(trd.fixing_date())
        , m_ex_rate_1(fx_spot_name(trd.ccy1(), trd.ccy2()))
        , m_ex_rate_2(fx_spot_name(configuration, trd.ccy2()))
        , m_ir_curve_ccy2(ir_curve_discount_name(trd.ccy2()))
        , m_fxfwd_curve(fx_forward_name(trd.ccy1(), trd.ccy2()))
        , m_fds(fds)
    {
    }


    double PricerFXForward::price(Market& mkt) const
    {
        MYASSERT(!(m_settle_dt < m_fixing_dt), "Settlement Date < Fixing Date. Trade is invalid.");
        ptr_disc_curve_t disc_ccy2 = mkt.get_discount_curve(m_ir_curve_ccy2);
        double df_ccy2 = disc_ccy2->df(m_settle_dt);
        MYASSERT(!(m_settle_dt < mkt.today()), "Settlement Date < Pricing Date. Trade is expired.");

        ptr_fxspot_curve_t m_fxspot_curve_1 = mkt.get_fxspot_curve(m_ex_rate_1);
        ptr_fxspot_curve_t m_fxspot_curve_2 = mkt.get_fxspot_curve(m_ex_rate_2);
        double ex_rate = m_fxspot_curve_2->spot(); // exchange rate, i.e. 1 base currency = x ccy2

        if (m_fixing_dt < mkt.today()) {
            double fwd = m_fds->get(m_ex_rate_1, m_fixing_dt);

            return m_amt * (fwd - m_strike) * df_ccy2 / ex_rate;
        }
        if (m_fixing_dt == mkt.today()) {
            double fwd = (m_fds->lookup(m_ex_rate_1, m_fixing_dt).second ? m_fds->get(m_ex_rate_1, m_fixing_dt) : m_fxspot_curve_1->spot());

            return m_amt * (fwd - m_strike) * df_ccy2 / ex_rate;
        }
        else {
            ptr_fxforward_curve_t fxfwd_curve = mkt.get_fxforward_curve(m_fxfwd_curve);
            double fwd = fxfwd_curve->fwd(m_fixing_dt);

            return m_amt * (fwd - m_strike) * df_ccy2 / ex_rate;
        }
    }

} // namespace minirisk