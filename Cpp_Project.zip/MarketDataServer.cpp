#include "MarketDataServer.h"
#include "Macros.h"
#include "Streamer.h"

#include <limits>

namespace minirisk {

// transforms FX.SPOT.EUR.USD into FX.SPOT.EUR
string mds_spot_name(const string& name)
{
	// NOTE: in a real system error checks should be stricter, not just on the last 3 characters
	MYASSERT((name.substr(name.length() - 3, 3) == "USD"),
		"Only FX pairs in the format FX.SPOT.CCY.USD can be queried. Got " << name);
	return name.substr(0, name.length() - 4);
}

unsigned from_name_to_tenor(const string& name)
{
	unsigned tenor = 0;
	std::regex reg("[.]");
	std::vector<std::string>v(std::sregex_token_iterator(name.begin(), name.end(), reg, -1),
		std::sregex_token_iterator());//sregex_token_iterator():allocator

	if (v[0] != "IR") { return 0; }
	string t = v[1];//e.g.: "IR.2W.USD" -> "2W"

	string d = t.substr(t.length() - 1, 1);
	unsigned num = std::stoi(t.substr(0, t.length() - 1));

	if (d == "Y")
	{
		tenor = num * 365;
	}
	else if (d == "M")
	{
		tenor = num * 30;
	}
	else if (d == "W")
	{
		tenor = num * 7;
	}
	else if (d == "D")
	{
		tenor = num;
	}

	return tenor;
}

MarketDataServer::MarketDataServer(const string& filename)
{
	std::ifstream is(filename);
	MYASSERT(!is.fail(), "Could not open file " << filename);
	do {
		string name;
		double value;
		is >> name >> value;
		//std::cout << name << " " << value << "\n";
		std::pair<unsigned, double> v;
		v.first = from_name_to_tenor(name);
		v.second = value;
		auto ins = m_data.emplace(name, v);
		MYASSERT(ins.second, "Duplicated risk factor: " << name);
	} while (is);
}

double MarketDataServer::get(const string& name) const
{
	auto iter = m_data.find(name);
	MYASSERT(iter != m_data.end(), "Market data not found: " << name);
	return iter->second.second;
}

std::pair<double, bool> MarketDataServer::lookup(const string& name) const
{
	auto iter = m_data.find(name);
	return (iter != m_data.end())  // found?
		? std::make_pair(iter->second.second, true)
		: std::make_pair(std::numeric_limits<double>::quiet_NaN(), false);
}

std::vector<std::string> MarketDataServer::match(const std::string& expr) const
{
	std::vector<std::string> result;
	std::regex r(expr);
	for (const auto& d : m_data) {
		if (std::regex_match(d.first, r)) {
			result.push_back(d.first);
		}
	}
	return result;
}

unsigned MarketDataServer::tenor(const string& name) const
{
	auto iter = m_data.find(name);
	MYASSERT(iter != m_data.end(), "Market data not found: " << name);
	return iter->second.first;
}

} // namespace minirisk

