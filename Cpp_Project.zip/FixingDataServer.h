#pragma once

#include <map>
#include <regex>
#include "Global.h"
#include "Date.h"

namespace minirisk {

struct FixingDataServer
{
public:
    FixingDataServer(const string& filename);

    // queries
    double get(const string& name, const Date& t) const;
    std::pair<double, bool> lookup(const string& name, const Date& t) const;

private:
    // for simplicity, assumes market data can only have type double
    //std::pair<string, Date> m_data;
    std::map<std::pair<string, Date>, double> m_data;

};


} // namespace minirisk





