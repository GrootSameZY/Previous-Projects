#pragma once

#include "IPricer.h"
#include "TradeFXForward.h"

namespace minirisk {

    struct PricerFXForward : IPricer
    {
        PricerFXForward(const TradeFXForward& trd, std::string& configuration, std::shared_ptr<const FixingDataServer>& fds);

        virtual double price(Market& m) const;

    private:
        double m_amt;
        double m_strike;
        Date   m_settle_dt;
        Date   m_fixing_dt;
        string m_ex_rate_1;
        string m_ex_rate_2;
        string m_ir_curve_ccy2;
        string m_fxfwd_curve;
        std::shared_ptr<const FixingDataServer> m_fds;
    };

} // namespace minirisk