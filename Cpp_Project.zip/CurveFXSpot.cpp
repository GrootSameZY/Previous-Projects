#include "CurveFXSpot.h"
#include "Market.h"
#include "Streamer.h"

#include <cmath>


namespace minirisk {

    CurveFXSpot::CurveFXSpot(Market* mkt,  const Date& today, const string& curve_name)
        : m_name(curve_name)
        , m_ccy1(curve_name.substr(fx_spot_prefix.length(), 3))//get the first currrency name. FX.SPOT.XXX.YYY -> XXX
        , m_ccy2(curve_name.substr(fx_spot_prefix.length() + 4 , 3))//get the second currrency name. FX.SPOT.XXX.YYY -> YYY
        , m_spot_ccy1(m_ccy1 == "USD" ? 1 : mkt->get_fx_spot(fx_spot_prefix + m_ccy1 + ".USD"))
        , m_spot_ccy2(m_ccy2 == "USD" ? 1 : mkt->get_fx_spot(fx_spot_prefix + m_ccy2 + ".USD"))
    {
    }

    double  CurveFXSpot::spot() const
    {
        MYASSERT(!(std::isnan(m_spot_ccy1) || std::isnan(m_spot_ccy2)),"Market data not found: " << fx_spot_prefix + (std::isnan(m_spot_ccy1) ? m_ccy1 : m_ccy2));
        return m_spot_ccy1 / m_spot_ccy2;
    }

} // namespace minirisk
