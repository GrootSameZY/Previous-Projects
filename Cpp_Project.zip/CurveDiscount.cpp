#include "CurveDiscount.h"
#include "Market.h"
#include "Streamer.h"

#include <cmath>


namespace minirisk {

CurveDiscount::CurveDiscount(Market *mkt, const Date& today, const string& curve_name)
    : m_today(today)
    , m_name(curve_name)
    , m_rate(mkt->get_yield(curve_name.substr(ir_curve_discount_prefix.length(),3)))
{
}

double  CurveDiscount::df(const Date& t) const
{
    MYASSERT((!(t < m_today)), "Curve " << m_name << ", DF not available before anchor date " << m_today << ", requested " << t);
    //double dt = time_frac(m_today, t);
	double rate = 0.0; 
	//unsigned di = t - m_today;
	unsigned di = unsigned(t - m_today);
	//long di = t - m_today;
	auto itlow = m_rate.lower_bound(di);
	Date lt;
	lt.init(m_today.serial() + m_rate.rbegin()->first);

	
	MYASSERT(itlow != m_rate.end(), "Curve " << m_name << ", DF not available beyond last tenor date " << lt << ", requested " << t);

	unsigned t2 = itlow->first;
	double r2 = itlow->second;
	unsigned t1 = 0;
	double r1 = 0;
	if (itlow != m_rate.begin())
	{
		--itlow;
		t1 = itlow->first;
		r1 = itlow->second;
	}
	rate = (r2 * t2 - r1 * t1) / (t2 - t1);

	return std::exp(-r1 * t1 / 365 - rate * (di - t1) / 365);
}

} // namespace minirisk
