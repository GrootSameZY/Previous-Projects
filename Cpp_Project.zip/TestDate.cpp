
#include <iomanip>
#include <iostream>
#include <algorithm>
#include "Date.h"
#include <time.h> 
#include <stdlib.h>
#include<cstdlib>
using namespace::minirisk;
using namespace std;

void test1()
{
	srand((unsigned)time(NULL));
	unsigned year = 0;
	unsigned month = 0;
	unsigned day = 0;
	int j = 0;
	for (int i = 0; i < 1000; i++)
	{
		year = rand() % 500 + 1800;
		month = rand() % 24;
		if (month <= 12)
		{
			switch (month)
			{
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				day = rand() % 30 + 32;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				day = rand() % 30 + 31;
				break;
			case 2:
			{
				if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
					day = rand() % 30 + 30;
				else
					day = rand() % 30 + 29;
			}
			}
		}
		else
			day = rand() % 60;
		try {
			Date D(year, month, day);
		}
		catch (std::invalid_argument&  e) {
			j++;
			std::cout << "  " << e.what() << endl;
			continue;
		}
	}
	std::cout << "  number of error: " << j << endl;
}
void test2()
{
	bool leap;
	array<unsigned, 12> days_in_month = { {31,28,31,30,31,30,31,31,30,31,30,31} };
	int flag = 1;
	for (unsigned y = 1900; y < 2200; ++y) {
		leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
		for (unsigned m = 1; m <= 12;) {
			for (unsigned d = 1; d <= days_in_month[m - 1] + ((m == 2 && leap) ? 1 : 0); ++d)
			{
				Date d_test(y, m, d);
				string at = d_test.to_string(1);
				string bt = std::to_string((int)d) + "-" + std::to_string((int)m) + "-" + std::to_string(y);
				if (1 == bt.compare(at))
				{
					flag = 0;
				}
			}
			m = m + 1;
		}
	}
	if (flag)
		std::cout << "  SUCCESS " << endl;
}

void test3()
{
	bool leap;
	int flag = 1;
	array<unsigned, 12> days_in_month = { {31,28,31,30,31,30,31,31,30,31,30,31} };
	int y_n, m_n, d_n;
	for (unsigned y = 1900; y < 2199; ++y) {
		leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
		for (unsigned m = 1; m <= 12; ++m) {
			for (unsigned d = 1; d <= days_in_month[m - 1] + ((m == 2 && leap) ? 1 : 0); ++d)
			{

				if (d == days_in_month[m - 1] + ((m == 2 && leap) ? 1 : 0))
				{
					if (m == 12)
					{
						y_n = y + 1; m_n = 1; d_n = 1;
					}
					else
					{
						y_n = y; m_n = m + 1; d_n = 1;
					}
				}
				else
				{
					y_n = y; m_n = m; d_n = d + 1;
				}
				if (y_n != 2200)
				{
					Date today(y, m, d);
					Date next(y_n, m_n, d_n);
					if (next.serial() - today.serial() != 1)
					{
						flag = 0;
					}
				}
			}
		}
	}
	if (flag == 1)
		std::cout << "  SUCCESS " << endl;
}


int main()
{
	std::cout << "do test 1: " << endl;
	test1();
	std::cout << "do test 2: " << endl;
	test2();
	std::cout << "do test 3: " << endl;
	test3();


	return 0;
}
